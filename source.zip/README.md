# Pace completion motion study

An original, fictional sports-interface capability sample. This is not a client case, a customer endorsement or a production native-app integration.

## Files and use

- `completion.json`: editable Lottie vector animation, 240 × 240, 60 fps, 120 frames, transparent background.
- `generate.cjs`: original paths, colours and keyframes. Run `node generate.cjs` to regenerate JSON.
- `index.html`: responsive browser preview with replay, frame inspection and reduced-motion support.
- `vendor/package/build/player/lottie_light.min.js`: unmodified lottie-web 5.13.0 player.
- `vendor/package/LICENSE.md`: third-party MIT licence.

Serve this directory through an HTTP static server and open index.html. Loading local JSON over file:// may be blocked by browser security. Source is deliberately small: no backend, analytics, API keys, purchases or account setup.

## Scope and limitations

Only this one completion state and browser SVG playback are demonstrated. iOS/Android players, existing design systems, Figma, PAG, Spine and Rive are not verified or claimed. The workout values and brand are fictional. Customer integration requires an agreed target player/version, reference, scope and acceptance check.

## Rights

Original sample artwork and application code are provided under the MIT licence in LICENSE. Third-party player retains its own licence. Built with Codex assistance. No client materials or external artwork are included.
